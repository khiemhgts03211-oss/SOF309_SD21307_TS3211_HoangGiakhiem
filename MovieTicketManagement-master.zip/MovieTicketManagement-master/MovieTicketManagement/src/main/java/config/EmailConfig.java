package config;

public class EmailConfig {

    // Gmail gửi OTP
    public static final String EMAIL =
            "ripnotdan000@gmail.com";

    // App Password của Gmail
    public static final String PASSWORD =
            "wvyy nyvv nlqc ucva";

    private EmailConfig() {
    }
}